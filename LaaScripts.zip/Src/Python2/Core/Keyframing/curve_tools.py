class CurveTools(object):

    def __init__(self):
        print('curve')
