class BakingTools(object):

    def __init__(self):
        print('baking2')
