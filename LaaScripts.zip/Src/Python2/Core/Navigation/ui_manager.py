class UiManager(object):

    def __init__(self):
        print('ui_manager')
