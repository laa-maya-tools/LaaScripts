import LaaScripts.Src.Python3.Core.Navigation.channels_filter
import LaaScripts.Src.Python3.Core.Navigation.smart_manipulator
import LaaScripts.Src.Python3.Core.Navigation.ui_manager

_channels_filter = channels_filter.ChannelsFilter()
_smart_manipulator = smart_manipulator.SmartManipulator()
_ui_manager = ui_manager.UiManager()

