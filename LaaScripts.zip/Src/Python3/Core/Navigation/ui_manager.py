class UiManager(object):

    def __init__(self):
        print('ui_manager')


if __name__ == "__main__":
    # rt = RetimingTools()
    # # rt.remove_inbetween(3)
    # rt.add_inbetween(1)
    print('test')
