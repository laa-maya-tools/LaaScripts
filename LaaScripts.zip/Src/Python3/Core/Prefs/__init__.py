import LaaScripts.Src.Python3.Core.Prefs.hotkey_manager

_hotkey_manager = hotkey_manager.HotkeyManager()

