import maya.cmds as cmd
from LaaScripts.Src.Python3.Utils import info_utils as info


class BakingTools(object):

    def __init__(self):
        print('baking')
