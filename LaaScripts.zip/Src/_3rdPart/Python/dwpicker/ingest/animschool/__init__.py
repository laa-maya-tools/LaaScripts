from dwpicker.ingest.animschool.converter import convert
