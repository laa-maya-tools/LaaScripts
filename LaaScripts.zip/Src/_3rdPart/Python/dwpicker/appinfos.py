VERSION = 0, 6, 1  # Version, Feature, Hotfix
RELEASE_DATE = 'September 16th 2022'
DW_WEBSITE = 'https://fr.dreamwall.be/'
DW_GITHUB = 'https://github.com/DreamWall-Animation'
