from LaaScripts.Src import trigger as trg
reload(trg)

trg.Trigger().load_timeline_sections()

from LaaScripts.Src import trigger as trg
reload(trg)

trg.Trigger().add_timeline_section()

from LaaScripts.Src import trigger as trg
reload(trg)

trg.Trigger().toggle_sync_mode()

from LaaScripts.Src import trigger as trg
reload(trg)

trg.Trigger().filter_all_channels()





